package com.example.ratiu.socialresponsibility.Activities;

import android.arch.persistence.room.Room;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.ratiu.socialresponsibility.Database.UserDatabase;
import com.example.ratiu.socialresponsibility.Domain.User;
import com.example.ratiu.socialresponsibility.R;

public class RegisterActivity extends AppCompatActivity {
    private static final String DATABASE_NAME = "social_network";
    private UserDatabase userDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        userDatabase = Room.databaseBuilder(getApplicationContext(),
                UserDatabase.class, DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .build();

        Spinner spinner = findViewById(R.id.genderEditRegister);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.genders, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        Button registerButton = findViewById(R.id.registerButtonRegister);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = ((EditText) findViewById(R.id.nameEditRegister)).getText().toString();
                String password = ((EditText) findViewById(R.id.passwordEditRegister)).getText().toString();
                String passwordAgain = ((EditText) findViewById(R.id.passwordAgainEditRegister)).getText().toString();
                String email = ((EditText) findViewById(R.id.emailEditRegister)).getText().toString();
                String location = ((EditText) findViewById(R.id.locationEditRegister)).getText().toString();
                String interest = ((EditText) findViewById(R.id.interestEditRegister)).getText().toString();
                String gender = ((Spinner) findViewById(R.id.genderEditRegister)).toString();
                Integer age = Integer.parseInt((((EditText) findViewById(R.id.ageEditRegister)).getText().toString()));

                if (password.equals(passwordAgain)) {
                    final User user = new User(name, password, email, location, interest, age, gender);

                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    userDatabase.daoAccess().registerUser(user);
                                }
                            }
                    ).start();

                    Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(intent);
                } else
                    Toast.makeText(RegisterActivity.this, "Password not identical in both fields", Toast.LENGTH_LONG).show();
            }
        });

    }
}
