package com.example.ratiu.socialresponsibility.Database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

import com.example.ratiu.socialresponsibility.DAO.UserDao;
import com.example.ratiu.socialresponsibility.Domain.User;

@Database(entities = {User.class}, version = 1, exportSchema = false)
public abstract class UserDatabase extends RoomDatabase {
    public abstract UserDao daoAccess() ;
}