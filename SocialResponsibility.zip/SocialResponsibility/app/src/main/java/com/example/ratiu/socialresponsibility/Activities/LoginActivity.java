package com.example.ratiu.socialresponsibility.Activities;

import android.arch.persistence.room.Room;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ratiu.socialresponsibility.Database.UserDatabase;
import com.example.ratiu.socialresponsibility.Domain.User;
import com.example.ratiu.socialresponsibility.R;

public class LoginActivity extends AppCompatActivity {
    private static final String DATABASE_NAME = "social_network";
    private UserDatabase userDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userDatabase = Room.databaseBuilder(getApplicationContext(),
                UserDatabase.class, DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .build();

        Button loginButton = findViewById(R.id.loginButtonLogin);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText usernameEdit = findViewById(R.id.usernameLogin);
                EditText passwordEdit = findViewById(R.id.passwordLogin);

                final String username = usernameEdit.getText().toString();
                final String password = passwordEdit.getText().toString();

                new Thread(
                        new Runnable() {
                            @Override
                            public void run() {
                                User u = userDatabase.daoAccess().authenticate(username, password);
                                if(u!=null) {
                                    Intent intent=new Intent(LoginActivity.this,MapsActivity.class);
                                    startActivity(intent);
                                }
                                else
                                {
                                    Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                                    startActivity(intent);}
                            }
                        }
                ).start();
            }
        });

        Button registerButton = findViewById(R.id.registerButtonLogin);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}
