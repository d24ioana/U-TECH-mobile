package com.example.ratiu.socialresponsibility.DAO;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.example.ratiu.socialresponsibility.Domain.User;

import java.util.List;

@Dao
public interface UserDao {

    @Insert
    void registerUser (User user);
    @Query("SELECT * FROM User")
    List<User> getAllUsers ();
    @Update
    void updateProfile (User user);
    @Query("SELECT * FROM User WHERE email=:email AND password=:pass")
    User authenticate(String email,String pass);
}